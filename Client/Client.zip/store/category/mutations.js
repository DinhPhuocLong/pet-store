export default {
    SET_CATEGORY(state, category) {
        state.category = category;
    },
}
