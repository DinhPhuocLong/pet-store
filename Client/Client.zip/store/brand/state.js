export default () => ({
    brands: []
});