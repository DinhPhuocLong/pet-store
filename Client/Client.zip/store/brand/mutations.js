export default {
    SET_BRAND(state, brands) {
        state.brands = brands;
    },
}
