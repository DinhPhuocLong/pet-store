export default () => ({
    products: [],
})