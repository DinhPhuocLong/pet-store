export default {
    SET_PRODUCT(state, products) {
        state.products = products;
    },
}
