export default () => ({
    cart: []
})