import Vue from 'vue'

import UIkit from 'uikit'

UIkit.container = '#__nuxt'

Vue.prototype.$uikit = UIkit
