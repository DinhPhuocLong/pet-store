<template>
    <div class="mt-20 w-[97%] xl:w-full mx-auto">
        <div
            class="w-11/12 md:w-full mx-auto
            lg:bg-transparent text-center pt-10
            bg-center bg-no-repeat px-6 lg:pb-32 
            py-20 md:pt-24 overflow-hidden rounded-lg"
            style="background: url('https://wpbingosite.com/wordpress/petio/wp-content/uploads/2021/03/banner-3.png'); background-color: #FFAF15;
            "
        >
            <p
                class="pt-10 text-4xl md:text-4xl text-white tracking-tight md:tracking-wide font-semibold leading-10 mb-4"
            >
                Chào mừng đến với PETMARKET
            </p>
            <p
                class="text-lg md:text-xl text-white font-semibold tracking-tight leading-6 mb-5"
            >
            Siêu thị cho thú cưng của bạn!
            </p>
            <nuxt-link
                to="/gioi-thieu"
                class="inline-block py-2.5 px-8 
                            font-bold text-white text-[16px]
                            hover:bg-red-800
                            rounded-full bg-black"
            >
                Về chúng tôi
            </nuxt-link>
        </div>
    </div>
</template>

<script>
export default {};
</script>

<style></style>
