<template>
    <div>
        <h1 class="font-semibold text-3xl text-center mb-6">
            Trending products
        </h1>
        <div
            class="w-full owl:grid owl:grid-cols-4 owl:gap-4 trending-product-carousel owl-carousel "
        >
            <div class="w-full box-border">
                <div
                    class="relative mx-px product-img border border-solid border-gray-200 rounded-lg overflow-hidden"
                >
                    <a href="#">
                        <img
                            src="https://wpbingosite.com/wordpress/petio/wp-content/uploads/2020/12/product-7-450x450.jpg"
                            class="mx-auto"
                            width="450"
                            height="450"
                            alt=""
                        />

                        <!-- product buttons -->
                        <div
                            class="flex flex-col text-center absolute bottom-2 right-2"
                        >
                            <a
                                href="#"
                                class="iline-block text-center w-10 h-10 leading-10 
                                    border border-solid border-gray-300 mb-2 rounded-full
                                    transform translate-x-12 transition-all duration-300
                                    hover:text-white hover:bg-red-500
                                    opacity-0 product-buttons"
                            >
                                <i class="fas fa-long-arrow-alt-right"></i>
                            </a>
                            <button
                                class="iline-block text-center w-10 h-10 leading-10 
                                    transform translate-x-12 transition-all duration-400
                                    hover:text-white hover:bg-red-500
                                    opacity-0 product-buttons
                                    border border-solid border-gray-300 mb-2 rounded-full"
                            >
                                <i class="far fa-heart focus:outline-none"></i>
                            </button>
                            <button
                                class="iline-block text-center w-10 h-10 leading-10 
                                    border border-solid border-gray-300 mb-2 rounded-full
                                    transform translate-x-12 transition-all duration-500
                                    hover:text-white hover:bg-red-500
                                    opacity-0 product-buttons hidden"
                            >
                                <i
                                    class="fas fa-shopping-cart focus:outline-none"
                                ></i>
                            </button>
                        </div>
                    </a>
                    <!-- sale -->
                    <div
                        class="block min-w-[52px] text-center bg-red-500 absolute rounded-full py-0.5 text-white text-md top-2 left-2"
                    >
                        -11%
                    </div>
                    <!-- tag -->
                    <div
                        class="block min-w-[52px] text-center bg-red-500 absolute rounded-full py-0.5 text-white text-md top-2 right-2"
                    >
                        Hot
                    </div>
                </div>
                <div class="px-10 py-4 text-[16px] font-bold text-center">
                    <!-- star -->
                    <p class="truncate">
                        <a class="hover:text-red-500 overflow-truncate" href="#"
                            >Ut rhoncus venenatis justo, eu vulputate nunc</a
                        >
                    </p>
                    <span class="text-red-600">45.000đ</span>
                </div>
            </div>

            <div class="w-full box-border">
                <div
                    class="relative mx-px product-img border border-solid border-gray-200 rounded-lg overflow-hidden"
                >
                    <a href="#">
                        <img
                            src="https://wpbingosite.com/wordpress/petio/wp-content/uploads/2020/12/product-7-450x450.jpg"
                            class="mx-auto"
                            width="450"
                            height="450"
                            alt=""
                        />

                        <!-- product buttons -->
                        <div
                            class="flex flex-col text-center absolute bottom-2 right-2"
                        >
                            <a
                                href="#"
                                class="iline-block text-center w-10 h-10 leading-10 
                                    border border-solid border-gray-300 mb-2 rounded-full
                                    transform translate-x-12 transition-all duration-300
                                    hover:text-white hover:bg-red-500
                                    opacity-0 product-buttons"
                            >
                                <i class="fas fa-long-arrow-alt-right"></i>
                            </a>
                            <button
                                class="iline-block text-center w-10 h-10 leading-10 
                                    transform translate-x-12 transition-all duration-400
                                    hover:text-white hover:bg-red-500
                                    opacity-0 product-buttons
                                    border border-solid border-gray-300 mb-2 rounded-full"
                            >
                                <i class="far fa-heart focus:outline-none"></i>
                            </button>
                            <button
                                class="iline-block text-center w-10 h-10 leading-10 
                                    border border-solid border-gray-300 mb-2 rounded-full
                                    transform translate-x-12 transition-all duration-500
                                    hover:text-white hover:bg-red-500
                                    opacity-0 product-buttons hidden"
                            >
                                <i
                                    class="fas fa-shopping-cart focus:outline-none"
                                ></i>
                            </button>
                        </div>
                    </a>
                    <!-- sale -->
                    <div
                        class="block min-w-[52px] text-center bg-red-500 absolute rounded-full py-0.5 text-white text-md top-2 left-2"
                    >
                        -11%
                    </div>
                    <!-- tag -->
                    <div
                        class="block min-w-[52px] text-center bg-red-500 absolute rounded-full py-0.5 text-white text-md top-2 right-2"
                    >
                        Hot
                    </div>
                </div>
                <div class="px-10 py-4 text-[16px] font-bold text-center">
                    <!-- star -->
                    <p class="truncate">
                        <a class="hover:text-red-500 overflow-truncate" href="#"
                            >Ut rhoncus venenatis justo, eu vulputate nunc</a
                        >
                    </p>
                    <span class="text-red-600">45.000đ</span>
                </div>
            </div>

            <div class="w-full box-border">
                <div
                    class="relative mx-px product-img border border-solid border-gray-200 rounded-lg overflow-hidden"
                >
                    <a href="#">
                        <img
                            src="https://wpbingosite.com/wordpress/petio/wp-content/uploads/2020/12/product-7-450x450.jpg"
                            class="mx-auto"
                            width="450"
                            height="450"
                            alt=""
                        />

                        <!-- product buttons -->
                        <div
                            class="flex flex-col text-center absolute bottom-2 right-2"
                        >
                            <a
                                href="#"
                                class="iline-block text-center w-10 h-10 leading-10 
                                    border border-solid border-gray-300 mb-2 rounded-full
                                    transform translate-x-12 transition-all duration-300
                                    hover:text-white hover:bg-red-500
                                    opacity-0 product-buttons"
                            >
                                <i class="fas fa-long-arrow-alt-right"></i>
                            </a>
                            <button
                                class="iline-block text-center w-10 h-10 leading-10 
                                    transform translate-x-12 transition-all duration-400
                                    hover:text-white hover:bg-red-500
                                    opacity-0 product-buttons
                                    border border-solid border-gray-300 mb-2 rounded-full"
                            >
                                <i class="far fa-heart focus:outline-none"></i>
                            </button>
                            <button
                                class="iline-block text-center w-10 h-10 leading-10 
                                    border border-solid border-gray-300 mb-2 rounded-full
                                    transform translate-x-12 transition-all duration-500
                                    hover:text-white hover:bg-red-500
                                    opacity-0 product-buttons hidden"
                            >
                                <i
                                    class="fas fa-shopping-cart focus:outline-none"
                                ></i>
                            </button>
                        </div>
                    </a>
                    <!-- sale -->
                    <div
                        class="block min-w-[52px] text-center bg-red-500 absolute rounded-full py-0.5 text-white text-md top-2 left-2"
                    >
                        -11%
                    </div>
                    <!-- tag -->
                    <div
                        class="block min-w-[52px] text-center bg-red-500 absolute rounded-full py-0.5 text-white text-md top-2 right-2"
                    >
                        Hot
                    </div>
                </div>
                <div class="px-10 py-4 text-[16px] font-bold text-center">
                    <!-- star -->
                    <p class="truncate">
                        <a class="hover:text-red-500 overflow-truncate" href="#"
                            >Ut rhoncus venenatis justo, eu vulputate nunc</a
                        >
                    </p>
                    <span class="text-red-600">45.000đ</span>
                </div>
            </div>
        </div>
    </div>
</template>
