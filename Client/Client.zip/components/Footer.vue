<template>
    <div>
        <!-- Footer -->
        <footer class="w-full bg-gray-100">
            <div class="w-full border-b border-solid border-gray-200">
                <div class="w-[94%] xl:w-11/12 max-w-[1440px] mx-auto">
                    <div
                        class="md:grid md:grid-cols-2 md:py-6 lg:grid-cols-3 justify-center"
                    >
                        <div
                            class="text-center md:text-left flex flex-col md:flex-row md:gap-6 items-center md:border-r border-solid border-gray-300"
                        >
                            <div
                                class="p-3 text-center text-2xl border-2 border-solid border-red-500 rounded-full w-14 h-14 leading-12 inline-block"
                            >
                                <svg
                                    xmlns="http://www.w3.org/2000/svg"
                                    viewBox="0 0 24 24"
                                >
                                    <path
                                        d="M19 9.062s-5.188-.333-7 1.938c2-4.896 7-5.938 7-5.938v-2l5 4-5 4.019v-2.019zm-18.974 14.938h23.947l-11.973-11.607-11.974 
                                11.607zm1.673-14l10.291-7.488 3.053 2.218c.712-.459 1.391-.805 1.953-1.054l-5.006-3.637-11.99 8.725v12.476l7.352-7.127-5.653-4.113zm15.753 
                                4.892l6.548 6.348v-11.612l-6.548 5.264z"
                                    />
                                </svg>
                            </div>
                            <div>
                                <h2 class="text-xl font-bold">
                                    Tham gia nhận thư để được giảm giá 10%
                                    <br />
                                    cho đơn hàng tiếp theo!
                                </h2>
                            </div>
                        </div>

                        <div class="text-center">
                            <p
                                class="text-gray-400 font-bold px-10 text-base my-4"
                            >
                                Đăng ký nhận thư để nhận được <br />
                                thông tin mới nhất
                            </p>
                        </div>

                        <div class="col-start-1 col-end-3 lg:col-auto mt-4">
                            <form
                                class="flex items-center w-full mx-auto border border-solid border-gray-300 rounded-full"
                                style="max-width: 480px;"
                            >
                                <input
                                    type="text"
                                    class="w-full border-black rounded-l-full 
                        outline-none py-4 ml-10 bg-gray-100 text-sm font-bold
                        "
                                    placeholder="Địa chỉ email"
                                />
                                <span class="">
                                    <input
                                        type="submit"
                                        value="ĐĂNG KÝ"
                                        class="block relative top-0 
                            bg-black rounded-full px-4 leading-4 h-11 m-1
                            text-xs text-white
                            "
                                    />
                                </span>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <!-- information -->
            <div class="w-full border-b border-solid border-gray-200 pb-10">
                <div class="w-[94%] xl:w-11/12 max-w-[1440px] mx-auto mt-4">
                    <div
                        class="grid md:grid-cols-2 lg:grid-cols-4 md:items-end lg:items-start"
                    >
                        <div class="md:mb-10">
                            <div class="py-4">
                                <img
                                    class="max-h-28"
                                    src="../static/logo.png"
                                    alt=""
                                />
                                <p
                                    class="text-sm font-medium text-gray-500 leading-6"
                                >
                                    Nếu bạn có bất kì thắc mắc gì hãy liên hệ
                                    cho chúng tôi
                                    <a href="#" class="text-yellow-600"
                                        >Longdpps10786@gmail.com.</a
                                    >
                                </p>
                            </div>
                            <div class="flex flex-col text-yellow-600">
                                <div
                                    class="flex flex-col md:flex-row md:items-center mb-2"
                                >
                                    <svg
                                        xmlns="http://www.w3.org/2000/svg"
                                        width="24"
                                        height="24"
                                        viewBox="0 0 24 24"
                                    >
                                        <path
                                            d="M12 0c-4.198 0-8 3.403-8 7.602 0 
                                        4.198 3.469 9.21 8 16.398 4.531-7.188 
                                        8-12.2 8-16.398 0-4.199-3.801-7.602-8-7.602zm0 11c-1.657 0-3-1.343-3-3s1.343-3 3-3 3 1.343 3 3-1.343 3-3 3z"
                                            fill="orange"
                                        />
                                    </svg>
                                    <span
                                        class="text-black text-sm font-bold mb-2"
                                        >Đường Hậu Giang, Phường 9, Quận 6,<br />
                                        TP.Hồ Chí Minh
                                    </span>
                                </div>
                                <div
                                    class="flex flex-col md:flex-row md:items-center mb-2 md:mb-0"
                                >
                                    <svg
                                        xmlns="http://www.w3.org/2000/svg"
                                        width="24"
                                        height="24"
                                        viewBox="0 0 24 24"
                                    >
                                        <path
                                            d="M20 22.621l-3.521-6.795c-.008.004-1.974.97-2.064 1.011-2.24 1.086-6.799-7.82-4.609-8.994l2.083-1.026-3.493-6.817-2.106 
                                        1.039c-7.202 3.755 4.233 25.982 11.6 22.615.121-.055 2.102-1.029 2.11-1.033z"
                                            fill="orange"
                                        />
                                    </svg>
                                    <span
                                        class="text-black text-sm font-bold mb-2 md:mb-0"
                                        >+84 394 718 199</span
                                    >
                                </div>
                            </div>
                            <ul class="flex gap-3 mt-6">
                                <li>
                                    <a
                                        href="https://google.com" target="_blank"
                                        class="bg-black inline-block w-9 h-9 rounded-full text-center leading-9
                                    text-white hover:bg-yellow-500"
                                    >
                                        <svg
                                            xmlns="http://www.w3.org/2000/svg"
                                            class="icon icon-tabler icon-tabler-brand-facebook inline-block"
                                            width="20"
                                            height="20"
                                            viewBox="0 0 24 24"
                                            stroke-width="1.5"
                                            stroke="white"
                                            fill="white"
                                            stroke-linecap="round"
                                            stroke-linejoin="round"
                                        >
                                            <path
                                                stroke="none"
                                                d="M0 0h24v24H0z"
                                                fill="none"
                                            />
                                            <path
                                                d="M7 10v4h3v7h4v-7h3l1 -4h-4v-2a1 1 0 0 1 1 -1h3v-4h-3a5 5 0 0 0 -5 5v2h-3"
                                            />
                                        </svg>
                                    </a>
                                </li>
                            </ul>
                        </div>
                        <div class="mt-10 md:mt-0 md:mb-10">
                            <p class="text-black font-bold text-lg py-4">
                                Corporate
                            </p>
                            <ul
                                class="text-gray-400 tracking-tight text-base font-normal"
                            >
                                <li class="my-0.5 hover:text-yellow-500">
                                    <a href="#">Careers</a>
                                </li>
                                <li class="my-0.5 hover:text-yellow-500">
                                    <a href="#">About Us</a>
                                </li>
                                <li class="my-0.5 hover:text-yellow-500">
                                    <a href="#">Event Sponsorships</a>
                                </li>
                                <li class="my-0.5 hover:text-yellow-500">
                                    <a href="#">Vendors</a>
                                </li>
                                <li class="my-0.5 hover:text-yellow-500">
                                    <a href="#">Affiliate Program</a>
                                </li>
                            </ul>
                        </div>

                        <div class="mt-10 md:mt-0 md:mb-10">
                            <p class="text-black font-bold text-lg py-4">
                                Corporate
                            </p>
                            <ul
                                class="text-gray-400 tracking-tight text-base font-normal"
                            >
                                <li class="my-0.5 hover:text-yellow-500">
                                    <a href="#">Careers</a>
                                </li>
                                <li class="my-0.5 hover:text-yellow-500">
                                    <a href="#">About Us</a>
                                </li>
                                <li class="my-0.5 hover:text-yellow-500">
                                    <a href="#">Event Sponsorships</a>
                                </li>
                                <li class="my-0.5 hover:text-yellow-500">
                                    <a href="#">Vendors</a>
                                </li>
                                <li class="my-0.5 hover:text-yellow-500">
                                    <a href="#">Affiliate Program</a>
                                </li>
                            </ul>
                        </div>

                        <div class="mt-10 md:mt-0 md:mb-10">
                            <p class="text-black font-bold text-lg py-4">
                                Corporate
                            </p>
                            <ul
                                class="text-gray-400 tracking-tight text-base font-normal"
                            >
                                <li class="my-0.5 hover:text-yellow-500">
                                    <a href="#">Careers</a>
                                </li>
                                <li class="my-0.5 hover:text-yellow-500">
                                    <a href="#">About Us</a>
                                </li>
                                <li class="my-0.5 hover:text-yellow-500">
                                    <a href="#">Event Sponsorships</a>
                                </li>
                                <li class="my-0.5 hover:text-yellow-500">
                                    <a href="#">Vendors</a>
                                </li>
                                <li class="my-0.5 hover:text-yellow-500">
                                    <a href="#">Affiliate Program</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div
                class="w-[94%] xl:w-11/12 max-w-[1440px] mx-auto text-center py-3 flex items-center justify-between"
            >
                <div>
                    <span class="text-black font-medium text-xs"
                        >@ 2021 FPT PETSTORE</span
                    >
                </div>
                <div>
                    <img
                        class="mx-auto mt-4 md:mt-0"
                        src="https://developers.momo.vn/images/favicon/ms-icon-310x310.png"
                        width="35px"
                        alt=""
                    />
                </div>
            </div>
        </footer>
    </div>
</template>

<script>
export default {};
</script>

<style></style>
