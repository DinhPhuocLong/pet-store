<template>
    <div>
        <nuxt-link
            class="rounded-full py-2 px-4 border text-gray-400 text-[13px] hover:text-white hover:bg-yellow-500"
            to="/">
        Beauty
        </nuxt-link>
    </div>
</template>
