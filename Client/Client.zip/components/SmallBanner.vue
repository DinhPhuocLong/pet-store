<template>
    <div class="mt-10 w-full">
        <div class="md:flex justify-center gap-4">
            <a href="#" class="block md:w-2/4 relative mb-4">
                <img
                    class="rounded-lg overflow-hidden w-full"
                    src="https://wpbingosite.com/wordpress/petio/wp-content/uploads/2021/03/banner-12.jpg"
                    alt="Banner Image"
                />

                <div
                    class="w-full px-4 lg:px-20 absolute top-2/4 transform -translate-y-2/4"
                >
                    <div
                        class="text-white text-xs font-bold mb-2 hidden lg:block"
                    >
                        20% OFF ALL ITEMS
                    </div>

                    <h3
                        class="mb-2.5 text-white font-bold text-2xl lg:text-4xl"
                    >
                        Hot Summer <br />
                        Deals
                    </h3>

                    <p
                        class="inline-block py-2.5 px-8 
                            font-bold text-white text-[16px]
                            hover:bg-red-800
                            rounded-full bg-red-500"
                    >
                        Shop Now
                    </p>
                </div>
            </a>

            <a href="#" class="block md:w-2/4 relative mb-4">
                <img
                    class="rounded-lg overflow-hidden w-full"
                    src="https://wpbingosite.com/wordpress/petio/wp-content/uploads/2021/03/banner-13.jpg"
                    alt="Banner Image"
                />

                <div
                    class="w-full px-4 lg:px-20 absolute top-2/4 transform -translate-y-2/4"
                >
                    <div
                        class="text-black text-xs font-bold mb-2 hidden lg:block"
                    >
                        TOYS, TREATS & LEASHES
                    </div>

                    <h3
                        class="mb-2.5 text-black font-bold text-2xl lg:text-4xl"
                    >
                        Now <br />
                        At Wilone
                    </h3>

                    <p
                        class="inline-block py-2.5 px-8 
                            font-bold text-white text-[16px]
                            hover:bg-red-800
                            rounded-full bg-red-500"
                    >
                        Shop Now
                    </p>
                </div>
            </a>
        </div>
    </div>
</template>
