<template>
    <h1>Trang thương hiệu</h1>
</template>

<script>
export default {

}
</script>

<style>

</style>