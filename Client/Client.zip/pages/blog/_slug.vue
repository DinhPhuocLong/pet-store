<template>
    <div>
        <div class="img-banner">
            <div class="m-auto mt-10 text-center ">
                <a
                    class="tracking-widest text-center text-xs text-yellow-500 hover:text-yellow-700 transition ease-out duration-300"
                    href="#"
                    >BACKPACK</a
                >
                <a
                    class="tracking-widest text-center text-xs text-yellow-500 hover:text-yellow-700 transition ease-out duration-300"
                    href="#"
                    >, FASHION</a
                >
                <a
                    class="tracking-widest text-center text-xs text-yellow-500 hover:text-yellow-700 transition ease-out duration-300"
                    href="#"
                    >, LIFE STYLE</a
                >
            </div>
            <div class="mt-2">
                <h3
                    class="text-5xl text-center hover:text-yellow-600 transition ease-out duration-700 font-black"
                >
                    <a href="#">Traveling Solo Is Awesome</a>
                </h3>
            </div>
            <div class="flex items-center justify-center text-[13px] py-3.5">
                <div class="flex items-center author">
                    <span class="text-gray-400 font-bold">
                        By :
                        <a
                            class="ml-1 text-black hover:text-yellow-500"
                            href="#"
                            >Long</a
                        >
                    </span>
                </div>
                <div class="text-gray-400 font-bold hover:text-yellow-500">
                    4 comments
                </div>
            </div>
            <div class="max-w-[1440px] w-full m-auto mb-10 mt-10 xl:mb-0">
                <img
                    class="rounded-lg m-auto"
                    src="https://wpbingosite.com/wordpress/petio/wp-content/uploads/2018/05/blog-1.jpg"
                    width="98%"
                    alt=""
                />
            </div>
        </div>

        <div
            class="max-w-[1440px] mx-auto mt-6 flex flex-wrap flex-col flex-col-reverse lg:flex-row justify-between font-nunito px-4"
        >
            <div class="w-full lg:w-1/5">
                <BlogSidebar />
            </div>
            <!-- end tag -->
            <!-- Content -->
            <div class="w-full lg:w-4/5 lg:pl-10 mb-10 lg:mb-0">
                <!-- content detail  -->
                <div class="w-full">
                    <p
                        class="text-gray-500 font-extralight leading-loose text-[14px] mt-2"
                    >
                        <span class="dropcap">L</span>ed mollis, eros et
                        ultrices tempus, mauris ipsum aliquam libero, non
                        adipiscing dolor urna a orci. Aenean commodo ligula eget
                        dolor. Nulla facilisi. Sed mollis, eros et ultrices
                        tempus, mauris ipsum aliquam libero, non adipiscing
                        dolor urna a orci. non, velit. Etiam rhoncus. Nunc
                        interdum lacus sit amet orci. Phasellus leo dolor,
                        tempus non, auctor et, hendrerit quis, nisiVivamus
                        aliquet elit ac nisl. Ut a nisl id ante tempus
                        hendrerit.Sed mollis, eros et ultrices tempus, mauris
                        ipsum aliquam libero, non adipiscing dolor urna a orci.
                        Aenean commodo ligula eget dolor. Nulla facilisi. Sed
                        mollis, eros et ultrices tempus, mauris ipsum aliquam
                        libero, non adipiscing dolor urna a orci. Duis arcu
                        tortor, suscipit eget, imperdiet nec, imperdiet iaculis,
                        ipsum. <br /><br />

                        Proin sapien ipsum, porta a, auctor quis, euismod ut,
                        mi. Nulla neque dolor, sagittis eget, iaculis quis,
                        molestie non, velit. Etiam rhoncus. Nunc interdum lacus
                        sit amet orci. Phasellus leo dolor, tempus non, auctor
                        et, hendrerit quis, nisi.
                    </p>
                </div>
                <div
                    class="h-40 flex flex-1 div mt-5 border-l-2 border-yellow-600"
                >
                    <div class="div w-12"></div>
                    <div class="w-5/6 div ml-50 ">
                        <h6 class="text-gray-300 text-6xl">"</h6>
                        <p
                            class="text-gray-600 font-extralight leading-relaxed"
                        >
                            Vivamus aliquet elit ac nisl. Ut a nisl id ante
                            tempus hendrerit. Phasellus accumsan cursus velitid
                            ante tempus hendrerit. Donec interdum, metus et
                            hendrerit aliquet”
                        </p>
                        <br /><span class="text-[12px] text-black font-bold"
                            >ROBERT SMITH</span
                        >
                    </div>
                </div>
                <div class="w-full mt-5">
                    <p
                        class="text-gray-500 font-extralight leading-loose text-[14px] mt-2"
                    >
                        Sed mollis, eros et ultrices tempus, mauris ipsum
                        aliquam libero, non adipiscing dolor urna a orci. Aenean
                        commodo ligula eget dolor. Nulla facilisi. Sed mollis,
                        eros et ultrices tempus, mauris ipsum aliquam libero,
                        non adipiscing dolor urna a orci. Duis arcu tortor,
                        suscipit eget, imperdiet nec, imperdiet iaculis, ipsum.
                        <br /><br />
                        Proin sapien ipsum, porta a, auctor quis, euismod ut,
                        mi. Nulla neque dolor, sagittis eget, iaculis quis,
                        molestie non, velit. Etiam rhoncus. Nunc interdum lacus
                        sit amet orci. Phasellus leo dolor, tempus non, auctor
                        et, hendrerit quis, nisi.
                    </p>
                </div>
                <div class="div img-product flex flex-1 mt-7">
                    <img
                        src="https://wpbingosite.com/wordpress/petio/wp-content/uploads/2018/05/blog-img-1170x403.jpg"
                        alt=""
                    />
                </div>
                <!-- end content detail  -->
                <!-- tag share  -->
                <div class="flex justify-between mt-8">
                    <div
                        class="flex flex-1 text-center text-black text-[14px] mt-2"
                    >
                        <p class="font-light mr-3">Tags:</p>
                        <div class="flex font-nunito">
                            <div>
                                <a
                                    class="rounded-full font-light py-2 px-4 border text-gray-500 text-[13px]
                                    hover:text-white hover:bg-yellow-500"
                                    href="#"
                                    >Beauty</a
                                >
                            </div>
                            <div class="pr-2">
                                <a
                                    class=" rounded-full font-light py-2 px-4 text-gray-500 border text-[13px]
                                    hover:text-white hover:bg-yellow-500"
                                    href="#"
                                    >Ear Care</a
                                >
                            </div>
                        </div>
                    </div>
                    <p class="font-light mr-3">Share:</p>
                    <div class="flex font-nunito">
                        <div>
                            <a
                                class="rounded-full font-light py-2 px-4 border text-black text-[13px]
                                hover:text-white hover:bg-yellow-500"
                                href="#"
                                >f</a
                            >
                        </div>
                        <div class="pl-2">
                            <a
                                class=" rounded-full font-light py-2 px-4 text-black border text-[13px]
                                hover:text-white hover:bg-yellow-500"
                                href="#"
                                >T</a
                            >
                        </div>
                        <div class="pl-3">
                            <a
                                class=" rounded-full font-light py-2 px-4 text-black border text-[13px]
                            hover:text-white hover:bg-yellow-500"
                                href="#"
                                >in</a
                            >
                        </div>
                    </div>
                </div>
                <!-- end tag share  -->
                <!-- pre next  -->
                <div
                    class="flex flex-1 border-t-2 border-b-2 border-gray-100 mt-5"
                >
                    <div class=" w-1/2 btn-pre p-12">
                        <a class="hover:text-yellow-300" href="">
                            <p class="text-xs font-extralight">PREVIOUS</p>
                            <p class="text-2xl font-medium">
                                A Beautyful Sunday Morning
                            </p>
                        </a>
                    </div>
                    <div class="h-28 m-auto border-r"></div>
                    <div class=" w-1/2 btn-next p-12">
                        <a class=" hover:text-yellow-300 " href="">
                            <p class="text-xs font-extralight">NEXT</p>
                            <p class="text-2xl font-medium">
                                A Beautyful Sunday Morning
                            </p>
                        </a>
                    </div>
                </div>
                <!-- end pre next -->
                <!-- Comment  -->
                <div class="comment">
                    <div class="mt-10">
                        <h3 class="text-3xl text-center  font-black">
                            <p>4 Comment</p>
                        </h3>
                    </div>
                    <div class="w-full flex flex-1 mt-5 border-b">
                        <div class="w-16">
                            <img
                                src="https://secure.gravatar.com/avatar/53444f91e698c0c7caa2dbc3bdbf93fc?s=70&d=mm&r=g"
                                alt=""
                            />
                        </div>
                        <div class="w-full ml-5 leading-loose">
                            <span class="flex text-xs">WPBINGO</span>
                            <a
                                class="flex text-[12px] text-gray-400 hover:text-yellow-300"
                                href=""
                                >June 15, 2018</a
                            >
                            <p
                                class="flex text-sm leading-relaxed text-gray-500 font-light mb-10"
                            >
                                Lorem, ipsum dolor sit amet consectetur
                                adipisicing elit. Iste provident in ratione
                                tenetur numquam molestias sed deleniti obcaecati
                                corrupti aliquid! Sunt, nulla. Omnis ducimus
                                eius error culpa, sint laborum doloremque.
                                Excepturi sequi culpa nulla vel maiores?
                                Obcaecati aut repudiandae iure tenetur, at
                                praesentium veniam est magnam officia cumque
                                culpa corporis sequi eveniet dolorum mollitia
                                quo ad saepe amet! Tempora, amet!
                            </p>
                        </div>
                        <div class="w-8 hover:text-yellow-300">
                            <a href=""
                                ><img
                                    src="https://as1.ftcdn.net/jpg/03/56/96/48/500_F_356964824_3dNx0OlvCo1CYPqlnHu3W29XHFbG2LCv.jpg"
                                    alt=""
                            /></a>
                        </div>
                    </div>
                    <div class="w-full flex flex-1 mt-5 border-b">
                        <div class="w-24"></div>
                        <div class="w-16">
                            <img
                                src="https://secure.gravatar.com/avatar/53444f91e698c0c7caa2dbc3bdbf93fc?s=70&d=mm&r=g"
                                alt=""
                            />
                        </div>
                        <div class="w-full ml-3 leading-loose">
                            <span class="flex text-xs">WPBINGO</span>
                            <a
                                class="flex text-[12px] text-gray-400 hover:text-yellow-300"
                                href=""
                                >June 15, 2018</a
                            >
                            <p
                                class="flex text-sm leading-relaxed text-gray-500 font-light mb-10"
                            >
                                Lorem, ipsum dolor sit amet consectetur
                                adipisicing elit. Iste provident in ratione
                                tenetur numquam molestias sed deleniti obcaecati
                                corrupti aliquid! Sunt, nulla. Omnis ducimus
                                eius error culpa, sint laborum doloremque.
                                Excepturi sequi culpa nulla vel maiores?
                                Obcaecati aut repudiandae iure tenetur, at
                                praesentium veniam est magnam officia cumque
                                culpa corporis sequi eveniet dolorum mollitia
                                quo ad saepe amet! Tempora, amet!
                            </p>
                        </div>
                        <div class="w-8 hover:text-yellow-300">
                            <a href=""
                                ><img
                                    src="https://as1.ftcdn.net/jpg/03/56/96/48/500_F_356964824_3dNx0OlvCo1CYPqlnHu3W29XHFbG2LCv.jpg"
                                    alt=""
                            /></a>
                        </div>
                    </div>
                    <div class="w-full flex flex-1 mt-5 border-b">
                        <div class="w-24"></div>
                        <div class="w-16">
                            <img
                                src="https://secure.gravatar.com/avatar/53444f91e698c0c7caa2dbc3bdbf93fc?s=70&d=mm&r=g"
                                alt=""
                            />
                        </div>
                        <div class="w-full ml-3 leading-loose">
                            <span class="flex text-xs">WPBINGO</span>
                            <a
                                class="flex text-[12px] text-gray-400 hover:text-yellow-300"
                                href=""
                                >June 15, 2018</a
                            >
                            <p
                                class="flex text-sm leading-relaxed text-gray-500 font-light mb-10"
                            >
                                Lorem, ipsum dolor sit amet consectetur
                                adipisicing elit. Iste provident in ratione
                                tenetur numquam molestias sed deleniti obcaecati
                                corrupti aliquid! Sunt, nulla. Omnis ducimus
                                eius error culpa, sint laborum doloremque.
                                Excepturi sequi culpa nulla vel maiores?
                                Obcaecati aut repudiandae iure tenetur, at
                                praesentium veniam est magnam officia cumque
                                culpa corporis sequi eveniet dolorum mollitia
                                quo ad saepe amet! Tempora, amet!
                            </p>
                        </div>
                        <div class="w-8 hover:text-yellow-300">
                            <a href=""
                                ><img
                                    src="https://as1.ftcdn.net/jpg/03/56/96/48/500_F_356964824_3dNx0OlvCo1CYPqlnHu3W29XHFbG2LCv.jpg"
                                    alt=""
                            /></a>
                        </div>
                    </div>
                    <div class="w-full flex flex-1 mt-5 border-b">
                        <div class="w-16">
                            <img
                                src="https://secure.gravatar.com/avatar/53444f91e698c0c7caa2dbc3bdbf93fc?s=70&d=mm&r=g"
                                alt=""
                            />
                        </div>
                        <div class="w-full ml-3 leading-loose">
                            <span class="flex text-xs">WPBINGO</span>
                            <a
                                class="flex text-[12px] text-gray-400 hover:text-yellow-300"
                                href=""
                                >June 15, 2018</a
                            >
                            <p
                                class="flex text-sm leading-relaxed text-gray-500 font-light mb-10"
                            >
                                Lorem, ipsum dolor sit amet consectetur
                                adipisicing elit. Iste provident in ratione
                                tenetur numquam molestias sed deleniti obcaecati
                                corrupti aliquid! Sunt, nulla. Omnis ducimus
                                eius error culpa, sint laborum doloremque.
                                Excepturi sequi culpa nulla vel maiores?
                                Obcaecati aut repudiandae iure tenetur, at
                                praesentium veniam est magnam officia cumque
                                culpa corporis sequi eveniet dolorum mollitia
                                quo ad saepe amet! Tempora, amet!
                            </p>
                        </div>
                        <div class="w-8 hover:text-yellow-300">
                            <a href=""
                                ><img
                                    src="https://as1.ftcdn.net/jpg/03/56/96/48/500_F_356964824_3dNx0OlvCo1CYPqlnHu3W29XHFbG2LCv.jpg"
                                    alt=""
                            /></a>
                        </div>
                    </div>
                </div>
                <!-- end comment  -->
                <!-- form  -->
                <div class="form">
                    <div class="mt-10">
                        <h3 class="text-3xl text-center  font-black">
                            <p>Leave a reply</p>
                        </h3>
                    </div>
                    <div class="mt-10">
                        <h3
                            class="text-[15px] font-light text-center  text-gray-600"
                        >
                            <p>Your email address will not be published.</p>
                        </h3>
                    </div>
                    <div class="w-full">
                        <div class="mt-5 ">
                            <input
                                class="w-full h-48 bg-gray-100 rounded-lg"
                                type="text"
                                name="fcmt"
                                placeholder="Comment"
                            /><br />
                        </div>
                        <div class="w-full flex flex-1 justify-between">
                            <div class="mt-5 w-1/2 mr-5">
                                <input
                                    class="w-full h-12 bg-gray-100 rounded-lg"
                                    type="text"
                                    name="fname"
                                    placeholder="Your Name"
                                /><br />
                            </div>
                            <div class="mt-5 w-1/2">
                                <input
                                    class="w-full h-12 bg-gray-100 rounded-lg"
                                    type="text"
                                    name="fmail"
                                    placeholder="Your Email"
                                /><br />
                            </div>
                        </div>
                        <div class="mt-5 ">
                            <input
                                class="w-full h-12 bg-gray-100 rounded-lg"
                                type="text"
                                name="fweb"
                                placeholder="Website"
                            /><br />
                        </div>
                    </div>
                    <div class="btn mt-10">
                        <div class="text-center text-black">
                            <div>
                                <a
                                    class="p-14 rounded-full font-light py-2 px-4 border text-black text-[17px]
                                        hover:text-white hover:bg-yellow-500"
                                    href="#"
                                    >Post Comment</a
                                >
                            </div>
                        </div>
                    </div>
                </div>
                <!-- end form  -->
            </div>
            <!-- end content  -->
        </div>
    </div>
</template>

<script>
export default {
    layout: "shop"
};
</script>

<style scoped>
.author::after {
    content: "";
    width: 1px;
    height: 18px;
    display: inline-block;
    background: #dedede;
    @apply mx-4;
}
</style>
