<template>
  <div class="font-nunito antialiased mb-12 lg:mb-0 body-color">
    <ProductDetailHeader />

    <!-- Contact Content-->
    <Nuxt />
    
    <TheFooter />
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>