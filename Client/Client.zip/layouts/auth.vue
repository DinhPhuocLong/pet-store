<template>
    <Nuxt />
</template>